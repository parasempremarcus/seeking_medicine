---
title: The Baki Project - Vol. 1
date: "2023-01-04"
description: "Uma breve atualização pós-compra dos ingredientes da dieta"
---

Nem cinco dias se passaram direito e aqui estamos nós para a primeira atualização do **The Baki Project**!

Esse capítulo será bem rápido, pois iremos comentar sobre a compra dos ingredientes para a formação da dieta, algumas mudanças da planilha do post anterior e valores (arguably, o mais importante).

***Player Status***: 19 anos | 50kg | 1,78m

### • Nova Dieta

Decidi diversificar um pouco mais a minha planilha anterior. Depois de ter escrito o post, passei mais dias vendo receitas interessantes com mais calorias, algo que eu preciso muito. Consequentemente, essa é a nova dieta:

![Nova Dieta - Pobre Edition](./02.png)

|Refeição|Carboidratos|Proteínas|Gorduras|Calorias|
:---: | :---: | :---:| :---:| :---:|
|**Café**|63|20|23|559|
|**Almoço**|114|53|10|766|
|**Lanche 1**|78|8|4|362|
|**Janta**|50|21|12|390|
|**Lanche 2**|61|10|13|378|
|--|||||
|**Total**|**366**|**112**|**62**|**2455**|

Eu mudei bastante coisa, principalmenete o café. Senti que eu não conseguiria sentir apetite para consumir isso todo dia de manhã, ainda mais quando eu percebi que **meu desejo por comida pela manhã é confuso**, eu tenho fome, mas não tenho vontade de comer, e isso é péssimo para ganhar peso.

Por isso, misturei algumas receitas de Teles e de vídeos no YouTube e fiz uma dieta mais cara, porém mais atrativa aos meus olhos. Mas, como dito no blog anterior, tudo pode mudar.

### • Vamos às Compras?

Fui a um mercado popular daqui onde eu moro, Atakadão, e o total da compra foi **R$ 131,27**.

![Ser Fitness não é Barato](./03.png)

Para finalizar o valor total, eu comprei um **ketchup** (R$ 3,59) para dar mais gosto e **1,5 litros de suco** com 132 kcal por 200ml (R$ 4,49) para dar uma boa acompanhada nesses primeiros dias. 

Além disso, minha mãe irá trazer 10 reais de presunto amanhã para acompanhar o jantar com ovos, novamente para dar um pouco mais de gosto, caso fique monótono.

### • Expectivativas e Conclusão

Hoje pela manhã, bem cedo, começa minha jornada. Eu espero muito que tudo dê certo, pois ainda existem várias incógnitas. A minha maior preocupação é se irei conseguir fazer o shake da manhã, tudo tem que dar certo, porque só tenho paciência para limpar o liquidificador uma vez. 

Talvez eu escreva algo sobre como foi o primeiro dia (porém, o pouco tempo que estou tendo agora dificulte minha escrita). A certeza é que, em duas semanas, eu faça um post sobre como está o meu progresso nesse período.

Tirando isso, que Deus esteja com todos!

--

[Isaías 53](https://youtu.be/7clLRGKd1q0) | Projeto Sola

[Twerk It Like Miley](https://youtu.be/D43MoSiQNKY) | Brandon Beal ft. Christopher

[Blame](https://youtu.be/70BASPcfWVQ) | Calvin Harris ft. John Newman

[No Handz](https://youtu.be/eHz2w1cUjjE) | Waka Flocka ft. CRNKN Remix

[Senhor do Bonfim](https://youtu.be/5Ob6ELtdCyo) | Baco Exu do Blues

[Autumn Ring Mini](https://youtu.be/nISdqRJMOwY) | Yung Buda